//charger la page complete avant de demarrer le javascript
document.addEventListener("DOMContentLoaded", function () {
//sur le bouton submit on appele un nombre de fonctions   
   var form = document.getElementById("qcm10");
   form.addEventListener("submit",
   
   (event) => {
     event.preventDefault();
     ScrollTop(); //aller en haut de la page
     fini(); //afficher les reponse en vert : vrai et rouge: faux
     showScore();// afficher le resultat
     changeCouleur();//changer la couleur du bouton envoyer
   }
   )
 });

function ScrollTop(){
//aller en haut de la page (scroll)
document.body.scrollLeft = 0;//position
document.body.scrollTop = 0;//position
document.documentElement.scrollTop = 0;

}


var final_score=0; 
// variable pour le resultat
//calculer le resultat une fois que les question sont rempli      
//boucle for pour calculer le resultat if la valeur qui est "checked" (cocher)
   //vaut 1 (value dans code html) la score finale rajoute 1 point et change de couleur (vert pour vrai)
   // else la couleur change en rouge (faux)
function fini(){
   
   for(let i=1;i<=10;i++){ 
         if (document.querySelector('input[name="reponse'+i+'"]:checked').value==1){
            document.querySelector('input[name="reponse'+i+'"]:checked + div').style.backgroundColor= "green";
         }
      
         else{
            document.querySelector('input[name="reponse'+i+'"]:checked + div').style.backgroundColor = "red";
         }
}
}
 //fonction pour afficher le score dans un div (html) qui est vide
 // pour afficher le score dans un div qui est en ce moment vide on fait appel a l'id
   // de l'element on veut changer dans innerHTML
   // on affiche le score par concation avec la variable final_score

function showScore(){
         for(let a=1;a<=10;a++){
               if (document.querySelector('input[name="reponse'+a+'"]:checked').value==1){
                  final_score=final_score+1;  
               }
         else{
            }
  
         document.getElementById("result").innerHTML ="Votre resultat est : " + (final_score)+"/10";
         }
      }
   
// changer la couleur quand toutes les questions sont cocher
// on change la couleur du bouton envoyer
// on recupere le bouton envoyer avec "getelementbyid", change de couleur
function changeCouleur (){
   document.getElementById("envoyer").style.backgroundColor=("orange");
      }
      