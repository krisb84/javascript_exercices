document.querySelector(".hamburger-menu").addEventListener("click", () => {
  document.querySelector(".nav-wrapper").classList.toggle("change");
});
