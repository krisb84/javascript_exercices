//charger la page complete avant de demarer javascript
document.addEventListener("DOMContentLoaded", function () {

  });  
  
//les boutons styler du button number (bouton nombre)
//une constante pour manipluer les valuers afficher

const minusButton1 = document.getElementById('minus1');
const plusButton1= document.getElementById('plus1');

const minusButton2 = document.getElementById('minus2');
const plusButton2= document.getElementById('plus2');

const minusButton3 = document.getElementById('minus3');
const plusButton3= document.getElementById('plus3');

const minusButton4 = document.getElementById('minus4');
const plusButton4= document.getElementById('plus4');

const minusButton5 = document.getElementById('minus5');
const plusButton5= document.getElementById('plus5');

const minusButton6 = document.getElementById('minus6');
const plusButton6= document.getElementById('plus6');

const minusButton7 = document.getElementById('minus7');
const plusButton7= document.getElementById('plus7');

//le nombre de pizza par champs (inputfield)
const inputField1 = document.getElementById('pizza1');
const inputField2 = document.getElementById('pizza2');
const inputField3 = document.getElementById('pizza3');
const inputField4 = document.getElementById('pizza4');
const inputField5 = document.getElementById('pizza5');
const inputField6 = document.getElementById('pizza6');
const inputField7 = document.getElementById('pizza7');

// constant totale pour calculer le prix des pizzas par champs
const total1 = document.getElementById('total1');
const total2 = document.getElementById('total2');
const total3 = document.getElementById('total3');
const total4 = document.getElementById('total4');
const total5 = document.getElementById('total5');
const total6 = document.getElementById('total6');
const total7 = document.getElementById('total7');
//constante pour calculer le prix final de tout les champs
const inputFieldFinal =document.getElementById('final_total');
let final_result=0;

/*pizza1*/


//onclick event : manipulation des boutons et changement de valeur en bas (decrementation)
// "if" : on veut pas des valeurs negatifs
//parseint : changemnt de string a nombre
minusButton1.addEventListener('click', event => {
  event.preventDefault();
  const currentValue1 = Number(inputField1.value) || 0;
  let price_final = Number(inputFieldFinal.value);
  if(currentValue1>0){
  inputField1.value = currentValue1 - 1;
  total1.value=inputField1.value*8;
  inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))+(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
   

}
else{}
});
//onclick event : manipulations des boutons et changement de valeur en haut (incrementation)
// pas de if valeurs negatifs pas possible
// parseint : changement de string a nombre
plusButton1.addEventListener('click', event => {
  event.preventDefault();
  const currentValue1 =Number(inputField1.value) || 0;
  
  let price_final = Number(inputFieldFinal.value);
  inputField1.value = currentValue1 + 1;
  total1.value=(inputField1.value*8); 
  inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))+(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
});

/*pizza 2*/
minusButton2.addEventListener('click', event => {
    event.preventDefault();
    const currentValue2 = Number(inputField2.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue2>0){
    inputField2.value = currentValue2 - 1;
    total2.value=inputField2.value*8;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))+(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  }
  else{}
  });
  plusButton2.addEventListener('click', event => {
    event.preventDefault();
    const currentValue2 = Number(inputField2.value) || 0;

    let price_final = Number(inputFieldFinal.value);
    inputField2.value = currentValue2 + 1;
    total2.value=inputField2.value*8;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))+(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));

  });

/*pizza3*/
minusButton3.addEventListener('click', event => {
    event.preventDefault();
    const currentValue3 = Number(inputField3.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue3>0){
    inputField3.value = currentValue3 - 1;
    total3.value=inputField3.value*9;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))+(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));

  }
  else{}
  
});
  plusButton3.addEventListener('click', event => {
    event.preventDefault();
    const currentValue3 = Number(inputField3.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    inputField3.value = currentValue3 + 1;
    total3.value=inputField3.value*9;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  });

  /*pizza4*/
minusButton4.addEventListener('click', event => {
    event.preventDefault();
    const currentValue4 = Number(inputField4.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue4>0){
    inputField4.value = currentValue4 - 1;
    total4.value=inputField4.value*9;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  }
  else{}
  });
  
  plusButton4.addEventListener('click', event => {
    event.preventDefault();
    const currentValue4 = Number(inputField4.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    inputField4.value = currentValue4 + 1;
    total4.value=inputField4.value*9;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  });

  /*pizza5*/
  minusButton5.addEventListener('click', event => {
    event.preventDefault();
    const currentValue5 = Number(inputField5.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue5>0){
    inputField5.value = currentValue5 - 1;
    total5.value=inputField5.value*10;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  }
  else{}
  });
  
  plusButton5.addEventListener('click', event => {
    event.preventDefault();
    const currentValue5 = Number(inputField5.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    inputField5.value = currentValue5 + 1;
    total5.value=inputField5.value*10;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  });
   /*pizza6*/
   minusButton6.addEventListener('click', event => {
    event.preventDefault();
    const currentValue6 = Number(inputField6.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue6>0){
    inputField6.value = currentValue6 - 1;
    total6.value=inputField6.value*11;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  }
  else{}
  });
  
  plusButton6.addEventListener('click', event => {
    event.preventDefault();
    const currentValue6 = Number(inputField6.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    inputField6.value = currentValue6 + 1;
    total6.value=inputField6.value*11;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  });

  /*pizza7*/
  minusButton7.addEventListener('click', event => {
    event.preventDefault();
    const currentValue7 = Number(inputField7.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    if(currentValue7>0){
    inputField7.value = currentValue7 - 1;
    total7.value=inputField7.value*12;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  }
  else{}
  });
  
  plusButton7.addEventListener('click', event => {
    event.preventDefault();
    const currentValue7 = Number(inputField7.value) || 0;
    let price_final = Number(inputFieldFinal.value);
    inputField7.value = currentValue7 + 1;
    total7.value=inputField7.value*12;
    inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
  });

    /*pizza7*/
    minusButton7.addEventListener('click', event => {
        event.preventDefault();
        const currentValue7 = Number(inputField7.value) || 0;
        let price_final = Number(inputFieldFinal.value);
        if(currentValue7>0){
        inputField7.value = currentValue7 - 1;
        total7.value=inputField7.value*12;
        inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));

      }
      else{}
      });
      
      plusButton7.addEventListener('click', event => {
        event.preventDefault();
        const currentValue7 = Number(inputField7.value) || 0;
        let price_final = Number(inputFieldFinal.value);
        inputField7.value = currentValue7 + 1;
        total7.value=inputField7.value*12;
        inputFieldFinal.value=((parseInt(total1.value))+(parseInt(total2.value))+(parseInt(total3.value))
  +(parseInt(total4.value))+(parseInt(total5.value))+(parseInt(total6.value))+(parseInt(total7.value)));
      });
